# configuration file for flask-email

email = "collegeenquirysystem@gmail.com"
password = "codespeedy"
